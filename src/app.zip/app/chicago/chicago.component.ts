import { Component, OnInit } from '@angular/core';
import { HttpService } from './../http.service';

@Component({
  selector: 'app-chicago',
  templateUrl: './chicago.component.html',
  styleUrls: ['./chicago.component.css']
})
export class ChicagoComponent implements OnInit {

  weather;
  temp;
  high;
  low;
  humidity;
  wind;
  clouds;

  constructor(private _httpService: HttpService) { }

  ngOnInit() {
    this.weather = this._httpService.retrieveTasks('seattle')
    .then( weather => {
      console.log(weather)
      this.high = weather.main.temp_max;
      this.low = weather.main.temp_min;
      this.weather = weather.weather.main
    });
  }

}
